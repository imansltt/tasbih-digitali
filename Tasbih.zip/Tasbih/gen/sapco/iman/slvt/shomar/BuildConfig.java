/** Automatically generated file. DO NOT MODIFY */
package sapco.iman.slvt.shomar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}