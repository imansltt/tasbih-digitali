package sapco.iman.slvt.shomar;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends ActionBarActivity {
	public int r ;
	public int rs=0;
	public int num;
	public int nm ;
	public String nums;
	public int vib=0;
	public String ch ;
	@Override
	 public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.root);
		
		
		LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(R.layout.action_bar, null);

		 ActionBar actionBar = getSupportActionBar();
			actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
			actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
			actionBar.setCustomView(view, new ActionBar.LayoutParams
		(ViewGroup.LayoutParams.MATCH_PARENT,
		 ViewGroup.LayoutParams.MATCH_PARENT));
		
		final DrawerLayout drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
			
		final ImageView b = (ImageView) findViewById (R.id.imageView1);
		drawer_layout.openDrawer(Gravity.LEFT);
		b.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				
				if(drawer_layout.isDrawerOpen(Gravity.LEFT)){
					drawer_layout.closeDrawers();
				}else {
					drawer_layout.openDrawer(Gravity.LEFT);
				}
		  }
		});
		final TextView adad = (TextView) findViewById(R.id.adad);
		final Switch checkBox1 = (Switch) findViewById(R.id.switch1);
		final RadioGroup rdg = (RadioGroup) findViewById(R.id.radioGroup1);
		final EditText et = (EditText) findViewById(R.id.editText1);
		final Button sh = (Button) findViewById(R.id.button3);
		
		rdg.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup arg0, int arg1) {
				switch (rdg.getCheckedRadioButtonId()) {
				case R.id.radio0:
					r = 0;
					et.setEnabled(false);
					break;
				case R.id.radio1:
					r = 1;
					et.setEnabled(false);
					break;
				case R.id.radio2:
					r = 2;
					et.setEnabled(false);
					break;
				case R.id.radio3:
					r = 3;
					et.setEnabled(true);
					break;

				default:
					break;
				}
				
			}
		});
		
		
		num = Integer.parseInt(adad.getText().toString());
		
		ImageView sc = (ImageView) findViewById(R.id.sc);
		final Vibrator v = (Vibrator) getSystemService(Main.VIBRATOR_SERVICE);
		final AlertDialog.Builder adb = new AlertDialog.Builder(this);
		
		sh.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				ch = et.getText().toString();
				num = 0;
				nums = String.valueOf(num);
				adad.setText(nums);
				drawer_layout.closeDrawer(Gravity.LEFT);
				if (rdg.getCheckedRadioButtonId() == R.id.radio3)
				{
					
						rs = Integer.parseInt(et.getText().toString());
						et.setText("");
				
				}
				
			}
		});
		
		sc.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (r == 0)
				{
					if(drawer_layout.isDrawerOpen(Gravity.LEFT)){
						
					}else {
						num = num+1;
						nums = String.valueOf(num);
						adad.setText(nums);
						
						if (checkBox1.isChecked() == true)
						{
							v.vibrate(100);
						}
						else if (checkBox1.isChecked() == false)
						{
							
						}
					}
				}
				else if (r == 1)
				{
					if (num < 99)
					{
						if(drawer_layout.isDrawerOpen(Gravity.LEFT)){
							
						}else {
							num = num+1;
							nums = String.valueOf(num);
							adad.setText(nums);
							
							if (checkBox1.isChecked() == true)
							{
								v.vibrate(100);
							}
							else if (checkBox1.isChecked() == false)
							{
								
							}
						}
					}
					else if(num == 99)
					{
						v.vibrate(1000);
						adb.setMessage("ذکر شما به پایان رسید.");
						AlertDialog alertDialog = adb.create();
						alertDialog.show();
						num = 0;
						nums = String.valueOf(num);
						adad.setText(nums);
						drawer_layout.openDrawer(Gravity.LEFT);
					}
				}
				else if (r == 2)
				{
					if (num < 99)
					{
						if(drawer_layout.isDrawerOpen(Gravity.LEFT)){
							
						}else {
							num = num+1;
							nums = String.valueOf(num);
							adad.setText(nums);
							
							if (checkBox1.isChecked() == true)
							{
								v.vibrate(100);
							}
							else if (checkBox1.isChecked() == false)
							{
								
							}
						}
						if (num == 34)
						{
							v.vibrate(1000);
							adb.setMessage("ذکر آلله اکبر به پایان رسید.");
							AlertDialog alertDialog = adb.create();
							alertDialog.show();
						}
						if (num == 67)
						{
							v.vibrate(1000);
							adb.setMessage("ذکر الحمد لله به پایان رسید");
							AlertDialog alertDialog = adb.create();
							alertDialog.show();
						}
					}
					else if (num == 99)
					{
						v.vibrate(1000);
						adb.setMessage("ذکر شما به پایان رسید.");
						AlertDialog alertDialog = adb.create();
						alertDialog.show();
						num = 0;
						nums = String.valueOf(num);
						adad.setText(nums);
						drawer_layout.openDrawer(Gravity.LEFT);
					}
				}
				else if (r == 3)
				{
					if (rs == 0)
					{
						adb.setMessage("لطفا تعداد ذکر را وارد کنید.");
						AlertDialog alertDialog = adb.create();
						alertDialog.show();
						drawer_layout.openDrawer(Gravity.LEFT);
					}
					else 
					{
						if (num < rs-1)
						{
							if(drawer_layout.isDrawerOpen(Gravity.LEFT)){
								
							}else {
								num = num+1;
								nums = String.valueOf(num);
								adad.setText(nums);
								
								if (checkBox1.isChecked() == true)
								{
									v.vibrate(100);
								}
								else if (checkBox1.isChecked() == false)
								{
									
								}
							}
						}
						else if (num == rs-1)
						{
							v.vibrate(1000);
							adb.setMessage("ذکر شما به پایان رسید.");
							AlertDialog alertDialog = adb.create();
							alertDialog.show();
							num = 0;
							nums = String.valueOf(num);
							adad.setText(nums);
							drawer_layout.openDrawer(Gravity.LEFT);
						}
					}
					
					
				}
				
		  }
		});
		
		Button reset = (Button) findViewById(R.id.reset);
		reset.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				
				adad.setText("0");
				num = 0;
				nums = "0";
				
		  }
		});
		Button about = (Button) findViewById(R.id.button2);
		about.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                ShowAlertDialog();
            }
       });
		Button dev = (Button) findViewById(R.id.btn2);
		dev.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
            	Intent intent = new Intent(Intent.ACTION_VIEW); 
            	intent.setData(Uri.parse("bazaar://collection?slug=by_author&aid=" + "sapco")); 
            	intent.setPackage("com.farsitel.bazaar"); 
            	startActivity(intent); 
            }
       });
		
			}
	 public void ShowAlertDialog() {
	        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Main.this);
	        alertDialog.setTitle("گروه نرم افزاری spaco");
	        alertDialog.setMessage("با سلام !"+"\n"+"ایمان سلطانی هستم از گروه نرم افزاری sapco."+"\n"+" یک برنامه تحت عنوان صلوات شمار برای شما آماده کرده که یک ابزار ساده و در عین حال کاربردی است و رابط کاربری سریع و آسانی دارد و امیدوارم نهایت استفاده رو از آن ببرید.");
	        // Setting Negative "NO" Button
	        alertDialog.setNegativeButton("خب",
	                new DialogInterface.OnClickListener() {
	                    public void onClick(DialogInterface dialog, int which) {
	                        dialog.cancel();
	                        
	                    }
	                });
	        alertDialog.show();
	    }
	 private static long back_pressed = 0L;
	 @Override
	 public void onBackPressed()
	 {
	 if (back_pressed + 2000 > System.currentTimeMillis()) super.onBackPressed();
	 else
	  Toast.makeText(getBaseContext(), "برای خروج یه بار دیگه کلیک کن !", Toast.LENGTH_SHORT).show();
	 back_pressed = System.currentTimeMillis();
	 }
}
